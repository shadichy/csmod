# Cool Stuffs mod
**by [Shadichy](https://github.com/shadichy) and [Công Duy](https://www.facebook.com/profile.php?id=100014836779779)**

-----

### Jobs to do:
* Add dinosaurs, dragons and eggs (very big eggs)
* Add some decorating blocks (bamboo things,..)
* More weapons! (spear,...)
* Gripes for longer-lasting tools, weapons
* Milk bottle, Cacao milk and Chocolate!
